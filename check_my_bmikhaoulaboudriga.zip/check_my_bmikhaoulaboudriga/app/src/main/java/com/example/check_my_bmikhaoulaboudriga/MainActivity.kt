package com.example.check_my_bmikhaoulaboudriga

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etWeight: EditText
    private lateinit var etHeight: EditText
    private lateinit var btnCalculateBMI: Button
    private lateinit var tvBMI: TextView
    private lateinit var tvInterpretation: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Initialize views
        etWeight = findViewById(R.id.etWeight)
        etHeight = findViewById(R.id.etHeight)
        btnCalculateBMI = findViewById(R.id.btnCalculateBMI)
        tvBMI = findViewById(R.id.tvBMI)
        tvInterpretation = findViewById(R.id.tvInterpretation)

        // Set click listener on the button
        btnCalculateBMI.setOnClickListener {
            calculateBMI()
        }
    }

    private fun calculateBMI() {
        // Get input values
        val weight = etWeight.text.toString().toFloatOrNull()
        val height = etHeight.text.toString().toFloatOrNull()

        // Check for valid input
        if (weight == null || height == null || height <= 0) {
            tvBMI.text = "Please enter valid weight and height."
            tvInterpretation.text = ""
            return
        }

        // Calculate BMI
        val bmi = weight / (height * height)

        // Display BMI
        tvBMI.text = String.format("BMI: %.2f", bmi)

        // Determine interpretation
        val interpretation = when {
            bmi < 18.5 -> "Underweight"
            bmi in 18.5..24.9 -> "Normal weight"
            bmi in 25.0..29.9 -> "Overweight"
            else -> "Obesity"
        }

        // Display interpretation
        tvInterpretation.text = interpretation
    }
}
