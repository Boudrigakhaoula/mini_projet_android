class DeleteProductActivity : AppCompatActivity() {
    // Instance du contrôleur pour gérer les opérations de suppression
    private lateinit var controller: Controller

    // Liaison avec le fichier XML de la vue
    private lateinit var binding: ActivityDeleteProductBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation de la liaison avec la vue
        binding = ActivityDeleteProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Récupération de l'instance du contrôleur (singleton)
        controller = Controller.getInstance()

        // Gestion du clic sur le bouton pour retourner à l'accueil
        binding.btnGoHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent) // Lancement de l'activité HomeActivity
        }

        // Gestion du clic sur le bouton "Supprimer"
        binding.btnDelete.setOnClickListener {
            Log.i("my Info", "Here in btnDelete listener ----------")

            // Récupération de la référence entrée par l'utilisateur
            val reference = binding.etReference.text.toString()

            // Affichage d'une boîte de dialogue de confirmation
            AlertDialog.Builder(this)
                .setTitle("Delete Product") // Titre de la boîte de dialogue
                .setMessage("Are you sure you want to delete this product?") // Message de confirmation
                .setPositiveButton("Yes") { _, _ ->
                    // L'utilisateur confirme la suppression
                    controller.deleteProduct(reference, applicationContext) // Appel au contrôleur pour supprimer le produit
                }
                .setNegativeButton("No", null) // Annulation de la suppression
                .show() // Affichage de la boîte de dialogue
        }
    }
}
