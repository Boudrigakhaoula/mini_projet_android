class AddProductActivity : AppCompatActivity() {
    // Liaison avec le fichier XML de la vue
    private lateinit var binding: ActivityAddProductBinding

    // Codes de requête pour distinguer les résultats des actions (caméra, galerie)
    private val CAMERA_REQUEST_CODE = 1
    private val GALLERY_REQUEST_CODE = 2

    // Messages d'alerte et de toast personnalisés
    private lateinit var permissionAlertText: String
    private lateinit var galleryPermissionDeniedToastText: String

    // Instance du contrôleur pour gérer l'ajout de produit
    private lateinit var controller: Controller
    private var imageUri: Uri? = null // URI de l'image sélectionnée/capturée

    // Chemin du fichier photo pris avec la caméra
    lateinit var currentPhotoPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation de la liaison de vue
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Chargement des messages depuis les ressources
        permissionAlertText = resources.getText(R.string.alert_msg).toString()
        galleryPermissionDeniedToastText = resources.getText(R.string.gallery_toast_msg).toString()

        // Gestion du clic sur le bouton "Accueil"
        binding.btnGoHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }

        // Initialisation du contrôleur
        controller = Controller.getInstance()

        // Gestion du clic sur le bouton "Ajouter un produit"
        binding.btnAdd.setOnClickListener {
            val reference = binding.etReference.text.toString()
            val priceStr = binding.etPrice.text.toString()
            val quantityStr = binding.etQuantity.text.toString()

            // Validation et conversion des champs prix et quantité
            val price = if (priceStr.isNotEmpty()) priceStr.toDouble() else 0.0
            val quantity = if (quantityStr.isNotEmpty()) quantityStr.toInt() else 0

            // Utilisation d'une image par défaut si aucune n'est sélectionnée
            val defaultImageUri = Uri.parse("android.resource://${packageName}/${R.drawable.picture}")
            val selectedImageUri = imageUri ?: defaultImageUri

            // Ajout du produit via le contrôleur
            controller.addProduct(reference, price, quantity, selectedImageUri, this)
        }

        // Gestion des clics pour accéder à la caméra ou à la galerie
        binding.ivCamera.setOnClickListener { checkPermissionForCamera() }
        binding.ivGallery.setOnClickListener { checkPermissionForGallery() }
        
        // Afficher un dialogue pour choisir une action photo
        binding.ivFrame.setOnClickListener { openPhotoDialog() }
        binding.ivProduct.setOnClickListener { openPhotoDialog() }
    }

    // Affiche un dialogue permettant de choisir entre la caméra et la galerie
    private fun openPhotoDialog() {
        val photoDialog = AlertDialog.Builder(this)
        photoDialog.setTitle(resources.getText(R.string.photo_dialog_title))
        photoDialog.setItems(arrayOf(
            resources.getText(R.string.photo_dialogue_item1).toString(),
            resources.getText(R.string.photo_dialogue_item2).toString()
        )) { _, which ->
            when (which) {
                0 -> openGallery() // Ouvrir la galerie
                1 -> dispatchTakePictureIntent() // Ouvrir la caméra
            }
        }
        photoDialog.show()
    }

    // Vérifie et demande les permissions pour accéder à la galerie
    private fun checkPermissionForGallery() {
        Dexter.withContext(this)
            .withPermission(READ_EXTERNAL_STORAGE)
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(response: PermissionGrantedResponse?) {
                    openGallery() // Permission accordée, ouvrir la galerie
                }

                override fun onPermissionDenied(response: PermissionDeniedResponse?) {
                    // Afficher un toast et une boîte de dialogue
                    Toast.makeText(this@AddProductActivity, galleryPermissionDeniedToastText, Toast.LENGTH_SHORT).show()
                    showRotationalDialogForPermission()
                }

                override fun onPermissionRationaleShouldBeShown(request: PermissionRequest?, token: PermissionToken?) {
                    showRotationalDialogForPermission() // Montrer une boîte de dialogue pour l'explication
                }
            }).onSameThread().check()
    }

    // Ouvre la galerie pour sélectionner une image
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    // Vérifie et demande les permissions pour utiliser la caméra
    private fun checkPermissionForCamera() {
        Dexter.withContext(this)
            .withPermissions(READ_EXTERNAL_STORAGE, android.Manifest.permission.CAMERA)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (it.areAllPermissionsGranted()) {
                            dispatchTakePictureIntent() // Permission accordée, ouvrir la caméra
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?, token: PermissionToken?
                ) {
                    showRotationalDialogForPermission() // Montrer une boîte de dialogue pour l'explication
                }
            }).onSameThread().check()
    }

    // Gère les résultats des actions (caméra, galerie)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                CAMERA_REQUEST_CODE -> {
                    binding.ivFrame.visibility = View.INVISIBLE
                    binding.ivProduct.visibility = View.VISIBLE
                    val file = File(currentPhotoPath)
                    // Charger l'image avec Coil
                    binding.ivProduct.load(Uri.fromFile(file)) {
                        crossfade(true)
                        crossfade(1000)
                        transformations(RoundedCornersTransformation(8.0F))
                    }
                }
                GALLERY_REQUEST_CODE -> {
                    binding.ivFrame.visibility = View.INVISIBLE
                    binding.ivProduct.visibility = View.VISIBLE
                    imageUri = data?.data
                    binding.ivProduct.load(imageUri) {
                        crossfade(true)
                        crossfade(1000)
                        transformations(RoundedCornersTransformation(8.0F))
                    }
                }
            }
        }
    }

    // Crée un fichier pour l'image capturée avec la caméra
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    // Lance une intention pour capturer une image avec la caméra
    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    Log.e("error", "Error creating image file: ${ex.message}")
                    null
                }
                photoFile?.also {
                    val photoURI: Uri = getUriForFile(this, "com.example.android.fileprovider", it)
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE)
                }
            }
        }
    }

    // Affiche une boîte de dialogue pour diriger l'utilisateur vers les paramètres d'autorisation
    private fun showRotationalDialogForPermission() {
        AlertDialog.Builder(this)
            .setMessage(permissionAlertText)
            .setPositiveButton("SETTINGS") { _, _ ->
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("CANCEL") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}
