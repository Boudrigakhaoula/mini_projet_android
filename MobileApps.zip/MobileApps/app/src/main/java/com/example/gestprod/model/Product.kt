package com.example.gestprod.model

data class Product(
    var ref: String = "",
    var price: Double = 0.0,
    var quantity: Long = 0,
    var imageUrl: String? = null
)
{
    override fun toString(): String {
        return "Product(ref='$ref', price=$price, quantity=$quantity, imageUrl=$imageUrl)"
    }
}
