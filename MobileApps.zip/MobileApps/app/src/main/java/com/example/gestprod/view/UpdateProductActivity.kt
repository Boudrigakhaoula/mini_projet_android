class UpdateProductActivity : AppCompatActivity() {
    // Constantes pour identifier les résultats des activités caméra et galerie
    private val CAMERA_REQUEST_CODE = 1
    private val GALLERY_REQUEST_CODE = 2

    // Variables pour la gestion des permissions et messages utilisateur
    private lateinit var permissionAlertText: String
    private lateinit var galleryPermissionDeniedToastText: String

    // Instance du contrôleur pour gérer les interactions avec les données
    private lateinit var controller: Controller

    // URI pour stocker l'image sélectionnée ou capturée
    private var imageUri: Uri? = null
    private lateinit var imageUrl: String

    // Chemin de l'image capturée avec la caméra
    lateinit var currentPhotoPath: String

    // Liaison avec les éléments de la vue
    private lateinit var binding: ActivityUpdateProductBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialisation de la liaison avec la vue
        binding = ActivityUpdateProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialisation des textes pour les messages utilisateur
        permissionAlertText = resources.getText(R.string.alert_msg).toString()
        galleryPermissionDeniedToastText = resources.getText(R.string.gallery_toast_msg).toString()

        // Récupération de l'instance du contrôleur
        controller = Controller.getInstance()

        // Gestion du clic sur le bouton pour retourner à l'accueil
        binding.btnGoHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }

        // Recherche d'un produit à partir de sa référence
        binding.ivLoop.setOnClickListener {
            val reference = binding.etReference.text.toString()
            controller.searchProduct(reference) { product ->
                Log.d(TAG, "Product returned : ${product.toString()}")

                if (product != null) {
                    // Si le produit est trouvé, affichage des informations et options
                    binding.etReference.isEnabled = false
                    binding.cardPrice.visibility = View.VISIBLE
                    binding.cardQuantity.visibility = View.VISIBLE
                    binding.frameLayout.visibility = View.VISIBLE
                    binding.ivCamera.visibility = View.VISIBLE
                    binding.ivGallery.visibility = View.VISIBLE

                    binding.apply {
                        etPrice.setText("${product.price}")
                        etQuantity.setText("${product.quantity}")
                        if (product.imageUrl.isNotEmpty()) {
                            ivFrame.visibility = View.INVISIBLE
                            ivProduct.visibility = View.VISIBLE
                            Picasso.get().load(product.imageUrl).into(ivProduct)
                            imageUrl = product.imageUrl
                        }
                    }
                } else {
                    // Si le produit n'existe pas, masquer les options et afficher un message
                    binding.cardPrice.visibility = View.INVISIBLE
                    binding.cardQuantity.visibility = View.INVISIBLE
                    binding.frameLayout.visibility = View.INVISIBLE
                    binding.ivCamera.visibility = View.INVISIBLE
                    binding.ivGallery.visibility = View.INVISIBLE
                    Toast.makeText(applicationContext, "The is no product with this reference!", Toast.LENGTH_SHORT).show()
                    Log.e(TAG, "Product does not exist for reference: $reference")
                }
            }
        }

        // Gestion des clics pour capturer ou sélectionner une image
        binding.ivCamera.setOnClickListener { checkPermissionForCamera() }
        binding.ivGallery.setOnClickListener { checkPermissionForGallery() }
        binding.ivFrame.setOnClickListener { openPhotoDialog() }
        binding.ivProduct.setOnClickListener { openPhotoDialog() }

        // Gestion du clic sur le bouton "Update"
        binding.btnUpdate.setOnClickListener {
            val reference = binding.etReference.text.toString()
            val priceStr = binding.etPrice.text.toString()
            val quantityStr = binding.etQuantity.text.toString()

            val price = if (priceStr.isNotEmpty()) priceStr.toDouble() else 0.0
            val quantity = if (quantityStr.isNotEmpty()) quantityStr.toInt() else 0

            // Mise à jour du produit avec les nouvelles données et l'image (si sélectionnée)
            imageUri?.let { controller.updateProduct(reference, price, quantity, it, this) }
            Log.i("MyInfo", "In btnUpdate listener, product updated : $reference")
        }
    }

    // Méthode pour afficher un dialogue pour choisir entre caméra et galerie
    private fun openPhotoDialog() {
        val photoDialog = AlertDialog.Builder(this)
        photoDialog.setTitle("Select Action")
        photoDialog.setItems(arrayOf(
            resources.getText(R.string.photo_dialogue_item1).toString(),
            resources.getText(R.string.photo_dialogue_item2).toString()
        )) { _, which ->
            when (which) {
                0 -> openGallery() // Ouvrir la galerie
                1 -> dispatchTakePictureIntent() // Prendre une photo
            }
        }
        photoDialog.show()
    }

    // Vérification des permissions pour accéder à la galerie
    private fun checkPermissionForGallery() {
        Dexter.withContext(this)
            .withPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(response: PermissionGrantedResponse?) {
                    openGallery()
                }

                override fun onPermissionDenied(response: PermissionDeniedResponse?) {
                    Toast.makeText(this@UpdateProductActivity, galleryPermissionDeniedToastText, Toast.LENGTH_SHORT).show()
                    showRotationalDialogForPermission()
                }

                override fun onPermissionRationaleShouldBeShown(request: PermissionRequest?, token: PermissionToken?) {
                    showRotationalDialogForPermission()
                }
            }).onSameThread().check()
    }

    // Ouverture de la galerie pour sélectionner une image
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    // Vérification des permissions pour utiliser la caméra
    private fun checkPermissionForCamera() {
        Dexter.withContext(this)
            .withPermissions(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.CAMERA
            ).withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (it.areAllPermissionsGranted()) {
                            dispatchTakePictureIntent()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(requests: MutableList<PermissionRequest>?, token: PermissionToken?) {
                    showRotationalDialogForPermission()
                }
            }).onSameThread().check()
    }

    // Gestion des résultats de la caméra et de la galerie
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                CAMERA_REQUEST_CODE -> {
                    binding.ivFrame.visibility = View.INVISIBLE
                    binding.ivProduct.visibility = View.VISIBLE
                    val file = File(currentPhotoPath)
                    binding.ivProduct.load(Uri.fromFile(file)) {
                        crossfade(true)
                        crossfade(1000)
                        transformations(RoundedCornersTransformation(8.0F))
                    }
                }
                GALLERY_REQUEST_CODE -> {
                    binding.ivFrame.visibility = View.INVISIBLE
                    binding.ivProduct.visibility = View.VISIBLE
                    imageUri = data?.data
                    binding.ivProduct.load(imageUri) {
                        crossfade(true)
                        crossfade(1000)
                        transformations(RoundedCornersTransformation(8.0F))
                    }
                }
            }
        }
    }

    // Création d'un fichier pour stocker une image capturée
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    // Démarrage de l'activité pour capturer une photo
    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                val photoFile: File? = try { createImageFile() } catch (ex: IOException) { null }
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(this, "com.example.android.fileprovider", it)
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE)
                }
            }
        }
    }

    // Affichage d'une boîte de dialogue pour guider l'utilisateur en cas de refus de permissions
    private fun showRotationalDialogForPermission() {
        AlertDialog.Builder(this)
            .setMessage(permissionAlertText)
            .setPositiveButton("SETTINGS") { _, _ ->
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("CANCEL") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}
