package com.example.gestprod.model

import android.content.ContentValues.TAG
import android.content.Context
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class FirestoreManager {
    private val db = Firebase.firestore
    private lateinit var storageRef : StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore

    fun addProduct(reference: String, price: Double, quantity: Int, imageUri: Uri?, context: Context?) {
        init()

        storageRef = storageRef.child("img:$reference:${System.currentTimeMillis()}")
        imageUri?.let {
            storageRef.putFile(it).addOnCompleteListener{ task ->
                if(task.isSuccessful){
                    storageRef.downloadUrl.addOnSuccessListener { uri ->

                        val product = hashMapOf(
                            "reference" to reference,
                            "price" to price,
                            "quantity" to quantity,
                            "picture" to uri.toString()
                        )

                        db.collection("Products")
                            .add(product)
                            .addOnSuccessListener { documentReference ->
                                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                                Toast.makeText(context, "Product uploaded successfully", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                            }
                    }
                }else{
                    Toast.makeText(context, task.exception?.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

        Log.i("my Info", "Here in AddProduct in Controller ----------")
    }

    fun searchProduct(reference: String, callback: (Product?) -> Unit) {
        val firebaseFirestore = FirebaseFirestore.getInstance()
        val collection = firebaseFirestore.collection("Products")
        val searchQuery = collection.whereEqualTo("reference", reference)

        searchQuery.get()
            .addOnSuccessListener { querySnapshot ->
                var product: Product? = null
                for (document in querySnapshot.documents) {
                    if (document.exists()) {
                        val reference = document.getString("reference") ?: ""
                        val price = document.getDouble("price") ?: 0.0
                        val quantity = document.getLong("quantity") ?: 0
                        val pictureUrl = document.getString("picture") ?: ""

                        product = Product(reference, price, quantity, pictureUrl)
                        Log.d(TAG, "Product found: $product")
                    } else {
                        Log.e(TAG, "Document does not exist for reference: $reference")
                    }
                }
                callback(product) // Pass the product back via callback
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error fetching document: $e")
                callback(null) // Notify failure via callback
            }
    }

    fun deleteProduct(reference: String, context: Context) {
        val firebaseFirestore = FirebaseFirestore.getInstance()
        val collection = firebaseFirestore.collection("Products")
        val searchQuery = collection.whereEqualTo("reference", reference)

        searchQuery.get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    if (document.exists()) {
                        // Get the storage reference from the document
                        val imageUrl = document.getString("picture")
                        if (imageUrl != null) {
                            val storageRef = FirebaseStorage.getInstance().getReferenceFromUrl(imageUrl)

                            // Delete the document from Firestore
                            document.reference.delete()
                                .addOnSuccessListener {
                                    Log.d(TAG, "DocumentSnapshot successfully deleted!")

                                    // Delete the image from Storage
                                    storageRef.delete()
                                        .addOnSuccessListener {
                                            Log.d(TAG, "Product image deleted successfully!")
                                            Toast.makeText(context, "Product deleted successfully!", Toast.LENGTH_SHORT).show()
                                        }
                                        .addOnFailureListener { e ->
                                            Log.e(TAG, "Error deleting product image: $e")
                                            Toast.makeText(context, "Failed to delete product image!", Toast.LENGTH_SHORT).show()
                                        }
                                }
                                .addOnFailureListener { e ->
                                    Log.e(TAG, "Error deleting document: $e")
                                    Toast.makeText(context, "Failed to delete product!", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            Log.e(TAG, "No imageUrl found in document: $reference")
                            Toast.makeText(context, "Failed to delete product image: No image found!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Log.e(TAG, "No such document for reference: $reference")
                        Toast.makeText(context, "Failed to delete product: Document not found!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error fetching document: $e")
                Toast.makeText(context, "Failed to delete product: Error fetching document!", Toast.LENGTH_SHORT).show()
            }
    }

    fun updateProduct(reference: String, price: Double, quantity: Int, imageUri: Uri?, context: Context?) {
        firebaseFirestore = FirebaseFirestore.getInstance()
        val collection = firebaseFirestore.collection("Products")
        val searchQuery = collection.whereEqualTo("reference", reference)

        searchQuery.get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {

                        var updates = hashMapOf<String, Any>(
                            "price" to price,
                            "quantity" to quantity
                        )

                        // Check if there is a new image to update
                        if (imageUri != null) {
                            Log.i("MyInfo", "imageUri is not null = $imageUri --------------------")
                            // Delete the existing image from storage if there is one
                            val currentImageUrl = document.getString("picture")
                            if (!currentImageUrl.isNullOrEmpty()) {
                                val storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(currentImageUrl)
                                storageReference.delete()
                                    .addOnSuccessListener {
                                        Log.d(TAG, "Existing image deleted successfully")
                                    }
                                    .addOnFailureListener { e ->
                                        Log.e(TAG, "Error deleting existing image: $e")
                                        // Continue even if deletion fails
                                    }
                            }

                            // Upload the new image to storage
                            val storageRef = FirebaseStorage.getInstance().reference
                                .child("Images/img:$reference:${System.currentTimeMillis()}")

                            storageRef.putFile(imageUri)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        storageRef.downloadUrl.addOnSuccessListener { uri ->
                                            updates["picture"] = uri.toString()
                                            // Update the document with the new image URL
                                            document.reference.update(updates)
                                                .addOnSuccessListener {
                                                    Log.d(TAG, "DocumentSnapshot successfully updated with new image!")
                                                    Toast.makeText(context, "Product updated successfully!", Toast.LENGTH_SHORT).show()
                                                }
                                                .addOnFailureListener { e ->
                                                    Log.e(TAG, "Error updating document with new image: $e")
                                                    Toast.makeText(context, "Failed to update product!", Toast.LENGTH_SHORT).show()
                                                }
                                        }
                                    } else {
                                        Toast.makeText(context, "Failed to upload new image: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error fetching document: $e")
                Toast.makeText(context, "Failed to update product: Error fetching document!", Toast.LENGTH_SHORT).show()
            }
    }

    private fun init() {
        storageRef = FirebaseStorage.getInstance().reference.child("Images")
        firebaseFirestore = FirebaseFirestore.getInstance()
    }

}