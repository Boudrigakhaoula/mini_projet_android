package com.example.gestprod.controller

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.gestprod.model.FirestoreManager
import com.example.gestprod.model.Product

/**
 * Controller class implementing the Singleton design pattern
 * 
 * Responsibilities:
 * - Manages interactions with FirestoreManager
 * - Provides a centralized point for product-related operations
 * - Controls access to database operations
 */
class Controller private constructor() {
    // Reference to FirestoreManager for database operations
    // Private to encapsulate direct database interactions
    private val firestoreManager: FirestoreManager = FirestoreManager()

    /**
     * Adds a new product to the database
     * 
     * @param reference Unique identifier for the product
     * @param price Product price
     * @param quantity Product stock quantity
     * @param imageUri Optional image URI for the product
     * @param context Android application context
     */
    fun addProduct(reference: String, price: Double, quantity: Int, imageUri: Uri?, context: Context?) {
        // Delegate product addition to FirestoreManager
        firestoreManager.addProduct(reference, price, quantity, imageUri, context)
    }

    /**
     * Searches for a product by its reference
     * 
     * @param reference Unique identifier for the product
     * @param callback Lambda function to handle the search result
     */
    fun searchProduct(reference: String, callback: (Product?) -> Unit) {
        // Perform product search via FirestoreManager
        firestoreManager.searchProduct(reference) { product ->
            // Invoke callback with the found product
            callback(product)
        }
    }

    /**
     * Deletes a product from the database
     * 
     * @param reference Unique identifier for the product to delete
     * @param context Android application context
     */
    fun deleteProduct(reference: String, context: Context) {
        // Delegate product deletion to FirestoreManager
        firestoreManager.deleteProduct(reference, context)
    }

    /**
     * Updates an existing product in the database
     * 
     * @param reference Unique identifier for the product
     * @param price Updated product price
     * @param quantity Updated product stock quantity
     * @param selectedImageUri Optional new image URI
     * @param context Android application context
     */
    fun updateProduct(reference: String, price: Double, quantity: Int, selectedImageUri: Uri?, context: Context) {
        // Delegate product update to FirestoreManager
        firestoreManager.updateProduct(reference, price, quantity, selectedImageUri, context)
    }

    /**
     * Companion object implementing the Singleton pattern
     * 
     * Ensures only one instance of Controller exists throughout the application
     */
    companion object {
        // Nullable instance of Controller
        private var instance: Controller? = null

        /**
         * Provides global access to the Controller instance
         * 
         * @return Singleton instance of Controller
         */
        fun getInstance(): Controller {
            // Lazy initialization of Controller instance
            if (instance == null) {
                // Create new instance if it doesn't exist
                instance = Controller()
                // Log creation of the instance (useful for debugging)
                Log.i("my Info", "Here in Controller, getInstance()---------")
            }
            // Return the existing or newly created instance
            return instance!!
        }
    }
}