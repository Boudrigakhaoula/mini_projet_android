class SearchProductActivity : AppCompatActivity() {
    // Instance du contrôleur pour gérer les interactions avec les données
    private lateinit var controller: Controller

    // Liaison avec le fichier XML de la vue
    private lateinit var binding: ActivitySearchProductBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation de la liaison avec la vue
        binding = ActivitySearchProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Gestion du clic sur le bouton pour retourner à l'accueil
        binding.btnGoHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent) // Lancement de l'activité HomeActivity
        }

        // Récupération de l'instance du contrôleur (singleton)
        controller = Controller.getInstance()

        // Gestion du clic sur le bouton "Rechercher"
        binding.btnSearch.setOnClickListener {
            Log.i("my Info", "Here in btnSearch listener ----------")

            // Récupération de la référence du produit entrée par l'utilisateur
            val reference = binding.etReference.text.toString()

            // Appel au contrôleur pour rechercher le produit
            controller.searchProduct(reference) { product ->
                Log.d(TAG, "Product returned : ${product.toString()}")

                // Si le produit est trouvé, affichage des informations
                if (product != null) {
                    binding.apply {
                        tvRef.text = "Reference: ${product.ref}" // Affichage de la référence
                        tvPrice.text = "Price: ${product.price} DTN" // Affichage du prix
                        tvQuantity.text = "Quantity: ${product.quantity}" // Affichage de la quantité

                        // Chargement de l'image à partir de l'URL avec Picasso
                        Picasso.get().load(product.imageUrl).into(ivPicture)
                    }
                } else {
                    // Si aucun produit n'est trouvé, afficher un message et des valeurs par défaut
                    Toast.makeText(
                        applicationContext,
                        "There is no product with this reference!",
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.e(TAG, "Product does not exist for reference: $reference")

                    // Mise à jour de la vue avec des données par défaut
                    binding.apply {
                        tvRef.text = "Reference: Not found"
                        tvPrice.text = "Price: 0.0 DTN"
                        tvQuantity.text = "Quantity: 0"
                        ivPicture.setImageDrawable(resources.getDrawable(R.drawable.picture))
                    }
                }
            }
        }
    }
}
