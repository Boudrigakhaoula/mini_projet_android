package com.example.gestprod.view

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gestprod.controller.ProductsAdapter
import com.example.gestprod.databinding.ActivityViewInventoryBinding
import com.example.gestprod.model.Product

class ViewInventoryActivity : AppCompatActivity() {

    // Liaison avec la vue via View Binding
    private lateinit var binding: ActivityViewInventoryBinding

    // Liste mutable pour stocker les produits
    private var productList = mutableListOf<Product>()

    // Adaptateur personnalisé pour gérer l'affichage des produits dans le RecyclerView
    private lateinit var adapter: ProductsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation de la liaison avec la vue
        binding = ActivityViewInventoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configuration du RecyclerView pour afficher la liste des produits
        binding.recyclerView.setHasFixedSize(true) // Optimisation des performances
        binding.recyclerView.layoutManager = LinearLayoutManager(this) // Affichage en liste verticale

        // Initialisation de l'adaptateur avec la liste des produits
        adapter = ProductsAdapter(productList)
        binding.recyclerView.adapter = adapter

        // Chargement de tous les produits à afficher dans l'inventaire
        adapter.loadAllProducts()

        // Gestion du clic sur le bouton pour retourner à la page d'accueil
        binding.btnGoHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}
