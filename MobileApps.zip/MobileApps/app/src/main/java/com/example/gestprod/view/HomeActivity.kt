class HomeActivity : AppCompatActivity() {
    // Liaison avec le fichier XML de la vue
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation de la liaison avec la vue
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Gestion du clic sur le bouton "Ajouter un produit"
        binding.addProduct.setOnClickListener {
            // Création d'une intention pour lancer l'activité AddProductActivity
            val intent = Intent(this, AddProductActivity::class.java)
            startActivity(intent) // Lancement de l'activité
        }

        // Gestion du clic sur le bouton "Mettre à jour un produit"
        binding.updateProduct.setOnClickListener {
            // Création d'une intention pour lancer l'activité UpdateProductActivity
            val intent = Intent(this, UpdateProductActivity::class.java)
            startActivity(intent)
        }

        // Gestion du clic sur le bouton "Rechercher un produit"
        binding.searchProduct.setOnClickListener {
            // Création d'une intention pour lancer l'activité SearchProductActivity
            val intent = Intent(this, SearchProductActivity::class.java)
            startActivity(intent)
        }

        // Gestion du clic sur le bouton "Voir l'inventaire"
        binding.viewInventory.setOnClickListener {
            // Création d'une intention pour lancer l'activité ViewInventoryActivity
            val intent = Intent(this, ViewInventoryActivity::class.java)
            startActivity(intent)
        }

        // Gestion du clic sur le bouton "Supprimer un produit"
        binding.deleteProduct.setOnClickListener {
            // Création d'une intention pour lancer l'activité DeleteProductActivity
            val intent = Intent(this, DeleteProductActivity::class.java)
            startActivity(intent)
        }
    }
}
