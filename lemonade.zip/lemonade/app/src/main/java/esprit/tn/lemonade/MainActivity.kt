package esprit.tn.lemonade

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var instructionTextView: TextView
    private lateinit var lemonImageView: ImageView

    private var appState = "select"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        instructionTextView = findViewById(R.id.tvInstruction)
        lemonImageView = findViewById(R.id.imageView)


        updateUI()

        lemonImageView.setOnClickListener {
            handleStateChange()
        }
    }

    private fun handleStateChange() {
        when (appState) {
            "select" -> appState = "squeeze"
            "squeeze" -> appState = "drink"
            "drink" -> appState = "restart"
            "restart" -> appState = "select"
        }
        updateUI()
    }

    private fun updateUI() {
        when (appState) {
            "select" -> {
                instructionTextView.text = "click to select a lemon!"
                lemonImageView.setImageResource(R.drawable.lemon_tree)
            }
            "squeeze" -> {
                instructionTextView.text = "click to juice the lemon!"
                lemonImageView.setImageResource(R.drawable.lemon_squeeze)
            }
            "drink" -> {
                instructionTextView.text = "click to drink your lemonade!"
                lemonImageView.setImageResource(R.drawable.lemon_drink)
            }
            "restart" -> {
                instructionTextView.text = "click to start again."
                lemonImageView.setImageResource(R.drawable.lemon_restart)
            }
        }
    }
}
