package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.annotation.IntegerRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val results = findViewById(R.id.results) as TextView
        val button_add = findViewById(R.id.button_add) as Button
        val button_sub = findViewById(R.id.button_sub) as Button
        val button_mul = findViewById(R.id.button_mul) as Button
        val button_div = findViewById(R.id.button_div) as Button


        fun getNum1 () : Int{
            val num1 = findViewById(R.id.editTextNumber1) as EditText
            return Integer.parseInt((num1.text.toString()))
        }

        fun getNum2 () : Int{
            val num2 = findViewById(R.id.editTextNumber3) as EditText
            return Integer.parseInt((num2.text.toString()))
        }

        button_add.setOnClickListener(View.OnClickListener {
            View -> results.text = (getNum1 () + getNum2 ()).toString()
        })

        button_sub.setOnClickListener(View.OnClickListener {
                View -> results.text = (getNum1 () - getNum2 ()).toString()
        })

        button_mul.setOnClickListener(View.OnClickListener {
                View -> results.text = (getNum1 () * getNum2 ()).toString()
        })

        button_div.setOnClickListener(View.OnClickListener {
                View -> results.text = (getNum1 () / getNum2 ()).toString()
        })

    }
}