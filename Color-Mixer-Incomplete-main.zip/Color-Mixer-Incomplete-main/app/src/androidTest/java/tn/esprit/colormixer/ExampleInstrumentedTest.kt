package tn.esprit.colormixer

// Importing necessary testing libraries
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*

/**
 * Instrumented Test Class for Android Application
 * 
 * Instrumented tests are run directly on an Android device or emulator,
 * allowing testing of app-specific functionality that requires an Android context.
 * 
 * Key characteristics:
 * - Runs on actual device/emulator
 * - Can access Android framework components
 * - Useful for testing app-specific functionality
 * 
 * This test class verifies basic app configuration and package name
 */
@RunWith(AndroidJUnit4::class) // Specifies the test runner for Android instrumentation tests
class ExampleInstrumentedTest {
    
    /**
     * Test method to verify the app's context and package name
     * 
     * This test ensures that:
     * 1. The app can be correctly instantiated
     * 2. The package name matches the expected value
     * 
     * How it works:
     * - Retrieves the context of the app under test
     * - Compares the actual package name with the expected package name
     */
    @Test // Marks this method as a test to be executed
    fun useAppContext() {
        // Retrieve the context of the app being tested
        // InstrumentationRegistry provides access to the test environment
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        
        // Assert that the package name matches the expected value
        // This helps verify the app's configuration and identity
        assertEquals(
            "tn.esprit.colormixer", // Expected package name
            appContext.packageName   // Actual package name from the context
        )
    }
}