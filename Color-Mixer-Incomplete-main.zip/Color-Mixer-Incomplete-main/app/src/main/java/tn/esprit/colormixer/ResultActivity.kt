package tn.esprit.colormixer

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import tn.esprit.colormixer.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {
    // TODO 18: Declare a view binding variable
    // lateinit allows initialization of the variable later, before its first use
    // This provides type-safe access to views in the layout
    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // TODO 19: Initialize view binding
        // Inflate the layout using view binding instead of traditional findViewById
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // TODO 20: Process the result from the previous activity
        // Retrieve name and result from intent extras, with a default value if not found
        val name = intent.getStringExtra(NAME) ?: "UNKNOWN"
        val result = intent.getStringExtra(RESULT) ?: FAILED

        // Set the name text (currently left empty, which might be an oversight)
        binding.txtName.text = name

        // Determine which view to setup based on the result
        // Show either success or failure screen
        if (result == SUCCESS) {
            setupSuccessView(name)
        } else {
            setupWrongView(name)
        }

        // TODO 21: Add click listener to quit button
        // Finish the activity when the button is clicked
        binding.btnQuit.setOnClickListener {
            finish() // Closes the current activity and returns to the previous one
        }
    }

    // Function to setup the UI for a successful result
    private fun setupSuccessView(name: String) {
        // Set background color to success color
        binding.rlBackground.setBackgroundColor(
            ContextCompat.getColor(this, R.color.success)
        )

        // Set result text to "SUCCESS"
        binding.txtResult.text = "SUCCESS"

        // Create a congratulatory message with the user's name
        binding.txtAnswer.text = "Congratulations $name!\n" +
                "Your answer is correct!"

        // Set success image
        // Make sure the ic_success drawable is added to your resources
        binding.imgResult.setImageResource(R.drawable.ic_success)

        // Set quit button background to success color
        binding.btnQuit.setBackgroundColor(
            ContextCompat.getColor(this, R.color.success)
        )
    }

    // Function to setup the UI for an incorrect result
    private fun setupWrongView(name: String) {
        // Set background color to error color
        binding.rlBackground.setBackgroundColor(
            ContextCompat.getColor(this, R.color.error)
        )

        // Set result text to "WRONG"
        binding.txtResult.text = "WRONG"

        // Create an apologetic message with the user's name
        // Note: The text says "Your answer is correct!" which seems like a mistake
        binding.txtAnswer.text = "Sorry $name!\n" + 
                "Your answer is correct!"

        // Set failure image
        // Make sure the ic_failure drawable is added to your resources
        binding.imgResult.setImageResource(R.drawable.ic_failure)

        // Set quit button background to error color
        binding.btnQuit.setBackgroundColor(
            ContextCompat.getColor(this, R.color.error)
        )
    }
}