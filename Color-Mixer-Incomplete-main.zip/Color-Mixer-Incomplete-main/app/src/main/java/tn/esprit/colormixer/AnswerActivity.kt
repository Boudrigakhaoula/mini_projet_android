package tn.esprit.colormixer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import com.google.android.material.snackbar.Snackbar
import tn.esprit.colormixer.databinding.ActivityAnswerBinding

class AnswerActivity : AppCompatActivity() {
    // TODO 12: Declare view binding variable
    // lateinit ensures the variable will be initialized before use
    // Provides type-safe access to views in the layout
    private lateinit var binding: ActivityAnswerBinding

    // Variables to store color mixing information passed from previous activity
    private var correctColor = "NONE"  // The correct mixed color
    private var name = "NONE"           // User's name
    private var color1 = "NONE"         // First selected color
    private var color2 = "NONE"         // Second selected color

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // TODO 13: Initialize view binding
        // Inflate the layout using view binding instead of findViewById
        binding = ActivityAnswerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // TODO 14: Retrieve data from intent with null safety
        // Extract color and name information passed from previous activity
        name = intent.getStringExtra(NAME) ?: "NONE"
        color1 = intent.getStringExtra(COLOR1) ?: "NONE"
        color2 = intent.getStringExtra(COLOR2) ?: "NONE"

        // Determine the correct mixed color based on color combination
        // Uses a when expression to define color mixing rules
        correctColor = when {
            // Blue + Yellow = Green
            (color1 == BLUE && color2 == YELLOW) || (color1 == YELLOW && color2 == BLUE) -> GREEN
            // Blue + Red = Purple
            (color1 == BLUE && color2 == RED) || (color1 == RED && color2 == BLUE) -> PURPLE
            // Red + Yellow = Orange
            (color1 == RED && color2 == YELLOW) || (color1 == YELLOW && color2 == RED) -> ORANGE
            // Default case if no mixing rule applies
            else -> "NONE"
        }

        // TODO 15: Display the selected colors to the user
        // Shows which colors the user initially chose
        binding.txtChoosed.text = "You chose $color1 and $color2"

        // TODO 16: Implement submit button click listener
        // Handles the submission of the user's color mixing answer
        binding.btnSubmit.setOnClickListener {
            // First, validate that a radio button is selected
            if (checkSelectedRadioButton()) {
                // Determine if the answer is correct
                val result = if (checkAnswer()) SUCCESS else FAILED

                // Create an intent to navigate to the ResultActivity
                val resultIntent = Intent(this, ResultActivity::class.java).apply {
                    putExtra(NAME, name)      // Pass user's name
                    putExtra(RESULT, result)  // Pass the result of the answer
                }
                startActivity(resultIntent)
            }
        }
    }

    // Validates that a radio button is selected
    private fun checkSelectedRadioButton(): Boolean {
        // Get the ID of the selected radio button
        val selectedId = binding.radioGroup.checkedRadioButtonId

        // If no radio button is selected, show a Snackbar warning
        if (selectedId == -1) {
            Snackbar.make(binding.root, "Please select one color!", Snackbar.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    // Checks if the selected color matches the correct mixed color
    private fun checkAnswer(): Boolean {
        // TODO 17: Validate the user's color mixing answer
        // Get the ID of the selected radio button
        val selectedId = binding.radioGroup.checkedRadioButtonId

        // Compare the selected radio button with the correct mixed color
        return when (selectedId) {
            R.id.rbPurple -> (correctColor == PURPLE)  // Check if Purple is correct
            R.id.rbGreen  -> (correctColor == GREEN)   // Check if Green is correct
            R.id.rbOrange -> (correctColor == ORANGE)  // Check if Orange is correct
            else -> false  // Return false for any unexpected selection
        }
    }
}