package tn.esprit.colormixer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import tn.esprit.colormixer.databinding.ActivityQuestionBinding

// TODO 2: Define constant values for color names to ensure consistency and avoid typos
const val RED = "Red"
const val BLUE = "Blue"
const val YELLOW = "Yellow"
const val PURPLE = "Purple"
const val GREEN = "Green"
const val ORANGE = "Orange"

// TODO 3: Define constant keys for intent extras to pass data between activities
const val NAME = "name"
const val MIXED_COLOR = "mixed_color"
const val COLOR1 = "color1"
const val COLOR2 = "color2"
const val RESULT = "result"
const val SUCCESS = "success"
const val FAILED = "failed"

class QuestionActivity : AppCompatActivity() {
    // TODO 4: Declare a binding variable to access views without findViewById
    // lateinit ensures the variable will be initialized before use
    private lateinit var binding: ActivityQuestionBinding

    // TODO 5: Declare variables to store color mixing information
    // These will be used to pass data to the next activity
    private var colorMixed: String = ""  // Stores the resulting mixed color
    private var color1: String = ""      // First selected color
    private var color2: String = ""      // Second selected color
    private var name: String = ""        // User's name

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // TODO 6: Initialize view binding and set the content view
        // This replaces setContentView with a type-safe way to inflate the layout
        binding = ActivityQuestionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // TODO 7: Set click listener for the mix button
        // When clicked, it will call the mixColor() function to process color mixing
        binding.btnMix.setOnClickListener {
            mixColor()
        }
    }

    private fun mixColor() {
        // TODO 8: Validate user name input
        // Retrieve name from text field and check if it's empty
        name = binding.tfFullName.text.toString()
        if (name.isEmpty()) {
            // Show a toast message if name is not entered
            Toast.makeText(this, "enter your name!", Toast.LENGTH_SHORT).show()
            return  // Exit the function if name is empty
        }

        // TODO 9: Collect selected colors and validate selection
        // Create a list to store checked colors
        val selectedColors = ArrayList<String>()
        
        // Add checked colors to the list
        if (binding.cbBlue.isChecked) selectedColors.add(BLUE)
        if (binding.cbYellow.isChecked) selectedColors.add(YELLOW)
        if (binding.cbRed.isChecked) selectedColors.add(RED)

        // Ensure exactly 2 colors are selected
        if (selectedColors.size != 2) {
            // Show a snackbar if color selection is incorrect
            Snackbar.make(binding.root, "Please select exactly 2 colors!", Snackbar.LENGTH_SHORT).show()
            return  // Exit the function if color selection is invalid
        }

        // Assign selected colors
        color1 = selectedColors[0]
        color2 = selectedColors[1]

        // TODO 10: Determine the mixed color based on color combination
        // Use a when expression to define color mixing rules
        colorMixed = when {
            (color1 == BLUE && color2 == YELLOW) || (color1 == YELLOW && color2 == BLUE) -> GREEN
            (color1 == BLUE && color2 == RED) || (color1 == RED && color2 == BLUE) -> PURPLE
            (color1 == RED && color2 == YELLOW) || (color1 == YELLOW && color2 == RED) -> ORANGE
            else -> ""  // Default case if no mixing rule applies
        }

        // TODO 11: Create and start the AnswerActivity with mixed color information
        // Use an Intent to pass data to the next activity
        val intent = Intent(this, AnswerActivity::class.java).apply {
            putExtra(NAME, name)          // Pass user's name
            putExtra(MIXED_COLOR, colorMixed)  // Pass the mixed color result
            putExtra(COLOR1, color1)      // Pass the first selected color
            putExtra(COLOR2, color2)      // Pass the second selected color
        }
        startActivity(intent)  // Launch the AnswerActivity
    }
}